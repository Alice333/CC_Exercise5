
//Joyce's code
//frameRate(10);
var facecolor;
var facenumber;
var armcolor;
var angle=0;
var x=-20;  //star on left, move right
var armnumber=0;

function setup() {

createCanvas(1000,500);  //Joyce's make a background of 1000 width and 500 height
background(255);  // Joyce's make the background white
armcolor=color(215,200,230);
facecolor=color(102,232,145);

frameRate(30);

}//end of setup



function draw() {
  
background(255);

normalArm(armcolor);

half_robot();
randomFace();
robot_face(facecolor);


apple();


antenna(color(200,150,40));

applehead(x, color(62,255,227));
  x++;
  if(x>20){
    x=-20;
  }


push();
translate(mouseX,mouseY);
scale(0.3);
half_robot();
pop();

push();
translate(mouseX+200,mouseY-200);
scale(0.6);
apple();
applehead(0, color(255,247,62));
pop();

push();
translate(600,390);
rotate(angle);
half_robot_feet();
angle+=PI/20;
pop();





}//end of draw

function half_robot(){ //Joyce's code
  stroke(0);
  //SPIKES
fill(125,90,165); // color purple
triangle(380,180,340,100,420,140);  //bottom triangle
triangle(420,140,420,60,480,120);  //middle triangle
triangle(480,120,500,20,520,120);  //top triangle

//ANTENNA
noFill(); 
strokeWeight(10); //as thick as 10
arc(680,140,160,160,radians(180),radians(270));  //bendy thing, black line
fill(135,215,255);// sky blue
strokeWeight(1); //as thin as 1
ellipse(680,60,40,40);  //ball, antenna ball

//ROBOT FEET
fill(140); //color gray
triangle(420,340,320,400,460,380);  //the shape of of the feet

//NORMAL FEET
//fill(215,200,230); //pale purple
//ellipse(600,390,120,40);  //the feet shape

//ROBOT ARMS
//arms
noFill();
strokeWeight(15);
curve(340,220,340,220,260,180,220,100);  //bendy arm1 line1
curve(340,220,260,180,220,100,220,100);  //arm1 line2
//shoulder
fill(100); //gray
strokeWeight(1);
ellipse(340,220,30,30);  //circe shoulder
//hand
fill(180); //gray
quad(220,100,200,100,160,40,220,80);   //quad hand
//ROBOT: lower1
//arm
noFill();
strokeWeight(15);
curve(340,280,340,280,140,220,140,340);//bendy arm2 line1
curve(340,280,140,220,140,340,140,340); //bendy arm2 line2
//shoulder
fill(100);//gray
strokeWeight(1); //as thin as 1
ellipse(340,280,30,30); //circle shoulder
//hand
fill(180); //gray
quad(140,340,140,360,200,400,160,340); //quad hand2

//NORMAL ARM
//fill(215,200,230); //pale purple
//arc(640,280,100,100,radians(-135),radians(45),CHORD);  //half circle arm

//ROBOT FACE
/* fill(180); //gray
arc(500,250,305,305,radians(110),radians(290),CHORD); //the face's shape
//outer eye
fill(100); //dark gray
ellipse(420,220,60,60);  // outer circle
fill(194,0,0); //red inner eye
//inner eye
strokeWeight(2); 
ellipse(420,220,30,30); //inner eye
//mouth
rect(420,300,100,30); //mouth outline
line(440,300,440,330);  //teeth
line(460,300,460,330);  //teeth
*/


//NORMAL FACE
fill(215,200,230);  //pale purple
strokeWeight(1); 
arc(500,250,300,300,radians(-70),radians(110),CHORD); // the face's shape
//eye
noFill();
strokeWeight(4); 
arc(580,240,60,60,radians(200),radians(340));  //smiling bendy eye
//mouth
strokeWeight(3);
arc(500,250,180,180,radians(30),radians(110)); // bendy line mouth
//blush
strokeWeight(1);
stroke(235,150,190); //the color pink
line(560,270,580,250); //left blush
line(580,270,600,250);//middle blush
line(600,270,620,250); //right blush
  
}//end of function half_robot()

//below are each part of the half_robot

function robot_face(a){
 
  fill(a); //gray
arc(500,250,305,305,radians(110),radians(290),CHORD); //the face's shape
//outer eye
fill(100); //dark gray
ellipse(420,220,60,60);  // outer circle
fill(194,0,0); //red inner eye
//inner eye
strokeWeight(2); 
ellipse(420,220,30,30); //inner eye
//mouth
rect(420,300,100,30); //mouth outline
line(440,300,440,330);  //teeth
line(460,300,460,330);  //teeth
}
function randomFace(){
  facecolor=color(random(255),random(255),random(255));
}


function normalArm(armcolor){
  fill(armcolor); //pale purple
arc(640,280,100,100,radians(-135),radians(45),CHORD);  //half circle arm

}
function mousePressed(){
  var armcolors= [color(255,0,0),color(80,232,77),color(170,41,232)]
  if(armnumber==0){
    armcolor= armcolors[0];
    armnumber++;
  }
  else if(armnumber==1){
    armcolor= armcolors[1];
    armnumber++;
  }
  else if(armnumber==2){
    armcolor= armcolors[2];
    armnumber=0;
  }
}




function antenna(c){//the color
noFill(); 
var c = c;
strokeWeight(10); //as thick as 10
arc(680,140,160,160,radians(180),radians(270));  //bendy thing, black line
fill(c);// sky blue
strokeWeight(1); //as thin as 1
ellipse(680,60,40,40);  //ball, antenna ball
  
}

function aboveArm(){
  noFill();
strokeWeight(15);
curve(340,220,340,220,260,180,220,100);  //bendy arm1 line1
curve(340,220,260,180,220,100,220,100);  //arm1 line2
//shoulder
fill(100); //gray
strokeWeight(1);
ellipse(340,220,30,30);  //circe shoulder
//hand
fill(180); //gray
quad(220,100,200,100,160,40,220,80);   //quad hand
}


function belowArm(){
  noFill();
strokeWeight(15);
curve(340,280,340,280,140,220,140,340);//bendy arm2 line1
curve(340,280,140,220,140,340,140,340); //bendy arm2 line2
//shoulder
fill(100);//gray
strokeWeight(1); //as thin as 1
ellipse(340,280,30,30); //circle shoulder
//hand
fill(180); //gray
quad(140,340,140,360,200,400,160,340); //quad hand2
}




function apple(){     //my code
  println(mouseX, mouseY);
  
  //head part includes eyes, mouth
  /*fill(255,0,0);
  ellipse(200,160,130,130);
  fill(30,30,30);
  rect(195,48,16,46);
  fill(90,100,30);
  triangle(168,137,156,151,180,151);
  triangle(217, 138,209,151, 225,151);
  fill(30,135,200);
  arc(190,184,30,30,0, PI+QUARTER_PI, CHORD);
  */
  
  //body part
  line(149,226,240,226);
  line(118,333,209,333);
  line(149,226,118,333);
  line(240,226,209,333);
  fill(0,255,0);
  
  //feet
  ellipse(140,335,30,40);
  fill(20,255,0);
  line(139,263,109,278);
  line(230,266,249,277);
  
  ellipse(183,335,30,40);
  
}//end of function apple()


function applehead(x,headcolor){
  
  var x= x*(-1);
 
  fill(headcolor);
  ellipse(200+x,160,130,130);
  fill(30,30,30);
  rect(195+x,48,16,46);
  fill(90,100,30);
  triangle(168+x,137,156+x,151,180+x,151);
  triangle(217+x, 138,209+x,151, 225+x,151);
  fill(30,135,200);
  arc(190+x,184,30,30,0, PI+QUARTER_PI, CHORD);
}//end of applehead


function applefeet(y){
  var y=y*(-1);
  for(i=0;i<30;i++){
   y=i; 
  }
  
  fill(20,255,0);
  ellipse(140,335+y,30,40);
  ellipse(183,335+y,30,40);
  
}//end of applefeet

function half_robot_feet(){
 
 fill(215,200,230); //pale purple
ellipse(0,0,120,40);  //the feet shape 
}//end of robot feet
